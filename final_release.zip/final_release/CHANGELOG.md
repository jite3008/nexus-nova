# Changelog
All notable changes to this project will be documented here.

## [1.0] - 2025-08-21
### Added
- Nuxes Nova rebrand and assets.
- Build and release documentation.
- Privacy policy draft and transfer agreement draft.
- Play Store mockups and logo variants.
- iOS Info.plist and minor SwiftUI branding tweaks.
