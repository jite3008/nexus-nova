# Invoice — Nuxes Nova Sale

Invoice Date: 2025-08-21

Seller: [Seller Name]
Buyer: [Buyer Name]

Description: Sale of Nuxes Nova mobile application (source code, assets, documentation, transfer of IP)
Amount: $8000.00 USD

Payment terms: 100% upfront via escrow or bank transfer.
