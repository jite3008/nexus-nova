package com.nuxes.ui.helpers

import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object NetworkClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Configure these via Settings screen in the app (stored in SharedPreferences)
    var apiEndpoint: String = "https://api.example.com/assistant" // replace with your endpoint
    var apiKeyHeaderName: String = "X-API-KEY"
    var apiKey: String? = null // set from settings

    fun sendTextMessage(message: String): Result<String> {
        return try {
            val json = JSONObject()
            json.put("message", message)
            val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
            val reqBuilder = Request.Builder()
                .url(apiEndpoint)
                .post(body)
            apiKey?.let { reqBuilder.addHeader(apiKeyHeaderName, it) }
            val req = reqBuilder.build()
            val resp = client.newCall(req).execute()
            if (!resp.isSuccessful) {
                Result.failure(Exception("HTTP ${'$'}{resp.code}: ${'$'}{resp.message}"))
            } else {
                val txt = resp.body?.string() ?: ""
                Result.success(txt)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}