package com.nuxes.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nuxes.ui.helpers.MessageRepository

@Composable
fun SettingsScreen(onSaved: () -> Unit = {}) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { MessageRepository(ctx) }
    var apiKey by remember { mutableStateOf(repo.loadApiKey() ?: "") }

    Column(Modifier.padding(16.dp)) {
        Text("Assistant Settings")
        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Public API Key") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            repo.saveApiKey(apiKey)
            onSaved()
        }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Save") 
        }
    }
}