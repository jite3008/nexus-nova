
import SwiftUI
import AVFoundation

struct ContentView: View {
    @State private var input: String = ""
    @State private var messages: [String] = []
    let tts = AVSpeechSynthesizer()

    var body: some View {
        VStack {
            List(messages, id: \.self) { m in Text(m) }
            HStack {
                TextField("Type a message…", text: $input)
                Button("Send") {
                    let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !text.isEmpty {
                        messages.append("user: " + text)
                        input = ""
                        let reply = "iOS scaffold ready. Link KMM shared PublicLLMClient for AI reply or use OpenAIClient for premium."
                        messages.append("assistant: " + reply)
                        speak(reply)
                    }
                }
            }.padding()
        }.navigationTitle("AssistantKMM iOS")
    }

    func speak(_ s: String) {
        tts.stopSpeaking(at: .immediate)
        tts.speak(AVSpeechUtterance(string: s))
    }
}
