
## iOS App Scaffold (Public APIs + attachments notes)

- This scaffold shows how to wire the KMM shared module and use AVSpeechSynthesizer TTS.
- To enable AI replies in iOS, export the KMM :shared framework and call PublicLLMClient from Swift via bridging.
- For image attachments on iOS, use UIImagePickerController in the Xcode project and pass file URLs to the shared Assistant.handle(text:attachmentUri:attachmentType:).
