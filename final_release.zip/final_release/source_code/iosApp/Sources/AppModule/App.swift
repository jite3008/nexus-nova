import SwiftUI

@main
struct AssistantApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}