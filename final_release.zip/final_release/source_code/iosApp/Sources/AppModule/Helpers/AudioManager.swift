import Foundation
import AVFoundation

// Simple audio manager stub - use AVAudioRecorder/AVAudioPlayer for production
class AudioManager: NSObject, AVAudioRecorderDelegate {
    var recorder: AVAudioRecorder?
    var player: AVAudioPlayer?

    func startRecording() {
        // TODO: request permission and start AVAudioRecorder
    }

    func stopRecording() -> URL? {
        // TODO: stop and return file URL
        return nil
    }

    func play(url: URL) {
        // TODO: AVAudioPlayer play
    }
}