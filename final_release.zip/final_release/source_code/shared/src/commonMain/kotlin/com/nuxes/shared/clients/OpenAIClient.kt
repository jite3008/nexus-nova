
package com.nuxes.shared.clients

import com.nuxes.shared.ChatMessage
import com.nuxes.shared.LLMClient
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

class OpenAIClient(private val apiKey: String, private val model: String = "gpt-3.5-turbo") : LLMClient {
    private val client = HttpClient {
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
    }
    override suspend fun chat(messages: List<ChatMessage>): String {
        val req = OpenAIChatRequest(model, messages.map { OpenAIMessage(it.role, it.content) })
        val resp: OpenAIChatResponse = client.post("https://api.openai.com/v1/chat/completions") {
            headers { append(HttpHeaders.Authorization, "Bearer $apiKey") }
            contentType(ContentType.Application.Json)
            setBody(req)
        }.body()
        return resp.choices.firstOrNull()?.message?.content ?: "No response."
    }
}

@Serializable data class OpenAIChatRequest(val model: String, val messages: List<OpenAIMessage>)
@Serializable data class OpenAIMessage(val role: String, val content: String)
@Serializable data class OpenAIChatResponse(val choices: List<Choice>) {
    @Serializable data class Choice(val message: OpenAIMessage)
}
