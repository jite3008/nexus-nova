import Foundation

class NetworkManager {
    static let shared = NetworkManager()
    var apiEndpoint: String = "https://api.example.com/assistant"
    var apiKeyHeaderName: String = "X-API-KEY"
    var apiKey: String? = nil

    func sendText(_ text: String, completion: @escaping (Result<String, Error>) -> Void) {
        guard let url = URL(string: apiEndpoint) else { completion(.failure(NSError(domain:"", code:0))); return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.addValue("application/json", forHTTPHeaderField: "Content-Type")
        if let k = apiKey { req.addValue(k, forHTTPHeaderField: apiKeyHeaderName) }
        let body = ["message": text]
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        let t = URLSession.shared.dataTask(with: req) { data, resp, err in
            if let err = err { completion(.failure(err)); return }
            guard let d = data, let s = String(data: d, encoding: .utf8) else { completion(.failure(NSError(domain:"", code:1))); return }
            completion(.success(s))
        }
        t.resume()
    }
}