import SwiftUI
import AVFoundation

class SpeechHelper: NSObject {
    static let shared = SpeechHelper()
    let synth = AVSpeechSynthesizer()
    func speak(_ text: String) {
        let utt = AVSpeechUtterance(string: text)
        utt.voice = AVSpeechSynthesisVoice(language: Locale.current.languageCode ?? "en-US")
        synth.speak(utt)
    }
}


struct ChatView: View {
    @State private var inputText: String = ""
    @State private var messages: [String] = ["Welcome! This is a polished chat."]

    var body: some View {
        VStack {
            List(messages, id: \ .self) { msg in
                Text(msg)
            }
            HStack {
                TextField("Type a message", text: $inputText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Button(action: {
                    // send and speak
                    let text = inputText
                    if !text.isEmpty {
                        messages.append("You: \(text)")
                        NetworkManager.shared.sendText(text) { res in
                            switch res {
                            case .success(let s):
                                DispatchQueue.main.async {
                                    messages.append("Assistant: \(s)")
                                    SpeechHelper.shared.speak(s)
                                }
                            case .failure(let e):
                                DispatchQueue.main.async { messages.append("Error: \(e.localizedDescription)") }
                            }
                        }
                        inputText = ""
                    }
                }, label: {
                    if !inputText.isEmpty {
                        messages.append("You: \(inputText)")
                        inputText = ""
                    }
                }) {
                    Image(systemName: "paperplane.fill")
                }
            }.padding()
        }
    }
}