// Branding updated to Nuxes Nova
import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(destination: SettingsView()) { Text("Settings") }
            }
            ChatView()
                .navigationTitle("Nuxes Nova")
        }
    }
}