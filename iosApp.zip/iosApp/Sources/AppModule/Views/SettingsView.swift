import SwiftUI

struct SettingsView: View {
    @State private var apiKey: String = UserDefaults.standard.string(forKey: "api_key") ?? ""

    var body: some View {
        Form {
            Section(header: Text("API")) {
                TextField("Public API Key", text: $apiKey)
                Button("Save") {
                    UserDefaults.standard.set(apiKey, forKey: "api_key")
                    NetworkManager.shared.apiKey = apiKey
                }
            }
        }.navigationTitle("Settings")
    }
}