﻿plugins {
    id("com.android.library")
    kotlin("multiplatform")
    id("org.jetbrains.kotlin.plugin.serialization")
}

kotlin {
    androidTarget("android") {
        compilations.all {
            kotlinOptions {
                jvmTarget = "1.8" // Use JVM 1.8 for broader compatibility
            }
        }
    }

    sourceSets {
        val commonMain by getting {
            dependencies {
                // Networking & Coroutines
                implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.0")
                implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0")
                implementation("io.ktor:ktor-client-core:2.3.9")
                implementation("io.ktor:ktor-client-content-negotiation:2.3.9")
                implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.9")
                implementation("androidx.compose.material:material-icons-extended:1.6.8")
                // Fix for the "Unresolved reference: datetime" and "Clock" errors
                implementation("org.jetbrains.kotlinx:kotlinx-datetime:0.5.0")
            }
        }
        val androidMain by getting {
            dependencies {
                implementation("io.ktor:ktor-client-okhttp:2.3.9")
            }
        }
    }
}

android {
    namespace = "com.nuxes.shared"
    compileSdk = 33 // Use a lower SDK version to fix the resource linking error

    defaultConfig {
        minSdk = 24
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

