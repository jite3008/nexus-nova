
package com.nuxes.shared

class Assistant(private val llm: LLMClient?, personality: Personality = Personality.FRIENDLY) {

    private val history = mutableListOf<ChatMessage>(
        ChatMessage("system", personality.systemPrompt)
    )

    suspend fun handle(text: String, attachmentUri: String? = null, attachmentType: String? = null): AssistantResult {
        val t = text.trim()

        // Commands
        val lower = t.lowercase()
        if (lower.startsWith("open ")) {
            val app = t.removePrefix("open ").trim()
            return when {
                app.contains("youtube", true) -> AssistantResult("Opening YouTube…", openAppHint = "youtube")
                app.contains("spotify", true) -> AssistantResult("Opening Spotify…", openAppHint = "spotify")
                app.contains("maps", true) || app.contains("map", true) -> AssistantResult("Opening Maps…", openAppHint = "maps")
                app.startsWith("http", true) -> AssistantResult("Opening link…", openUrl = app)
                else -> AssistantResult("Trying to open $app…", openAppHint = app)
            }
        }
        if (lower.startsWith("play ")) {
            val q = t.removePrefix("play ").trim()
            return when {
                q.contains("spotify", true) -> AssistantResult("Playing on Spotify…", mediaQuery = q, target = "spotify")
                else -> AssistantResult("Searching on YouTube…", mediaQuery = q, target = "youtube")
            }
        }
        if (lower.startsWith("search ") || lower.startsWith("google ")) {
            val q = t.removePrefix("search ").removePrefix("google ").trim()
            val url = "https://duckduckgo.com/?q=" + q.replace(" ", "+")
            return AssistantResult("Here’s what I found for $q.", openUrl = url, target = "web")
        }
        if (lower.startsWith("call ")) {
            val num = t.removePrefix("call ").trim()
            return AssistantResult("Opening dialer for $num…", dialNumber = num)
        }
        if (lower.startsWith("sms ")) {
            val content = t.removePrefix("sms ").trim()
            val parts = content.split(" ", limit = 2)
            val num = parts.getOrNull(0) ?: ""
            val body = parts.getOrNull(1) ?: ""
            return AssistantResult("Opening SMS to $num…", smsTo = num, smsBody = body)
        }

        // Attachments: if an image or file attached, echo in chat and optionally analyze via LLM text only
        if (attachmentUri != null) {
            history += ChatMessage("user", "Attached file: $attachmentUri", attachmentUri = attachmentUri, attachmentType = attachmentType)
            // For now, we pass textual context to LLM (file processing requires server-side or on-device libs)
            if (llm != null) {
                val reply = llm.chat(history)
                history += ChatMessage("assistant", reply)
                return AssistantResult(reply)
            }
            return AssistantResult("Received attachment: $attachmentUri")
        }

        // AI / Public LLM
        if (llm != null) {
            history += ChatMessage("user", t)
            val reply = llm.chat(history)
            history += ChatMessage("assistant", reply)
            return AssistantResult(reply)
        }

        return AssistantResult("I heard: $t")
    }
}
