
package com.nuxes.shared

interface LLMClient {
    suspend fun chat(messages: List<ChatMessage>): String
}
