
package com.nuxes.shared

import kotlinx.datetime.Clock
import kotlinx.serialization.Serializable

@Serializable
data class ChatMessage(val role: String, val content: String, val timestamp: Long = Clock.System.now().toEpochMilliseconds(), val attachmentUri: String? = null, val attachmentType: String? = null)

enum class Personality(val systemPrompt: String) {
    FRIENDLY("You are a friendly helpful AI assistant. Keep replies concise."),
    PROFESSIONAL("You are a precise, professional assistant with a formal tone."),
    FUN("You are a playful assistant who keeps things light while being helpful.");
}

data class AssistantResult(
    val text: String,
    val openAppHint: String? = null,
    val openUrl: String? = null,
    val mediaQuery: String? = null,
    val target: String? = null,
    val dialNumber: String? = null,
    val smsTo: String? = null,
    val smsBody: String? = null
)
