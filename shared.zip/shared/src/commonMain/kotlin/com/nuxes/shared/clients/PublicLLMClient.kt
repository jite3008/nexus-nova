
package com.nuxes.shared.clients

import com.nuxes.shared.ChatMessage
import com.nuxes.shared.LLMClient
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.coroutines.*

/**
 * Keyless client: tries DuckDuckGo Instant Answer API, then Wikipedia summary as fallback.
 */
class PublicLLMClient : LLMClient {
    private val client = HttpClient {
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
    }

    override suspend fun chat(messages: List<ChatMessage>): String = coroutineScope {
        val user = messages.lastOrNull { it.role == "user" }?.content?.trim().orEmpty()
        if (user.isBlank()) return@coroutineScope "Hi! Ask me anything."

        // Try DuckDuckGo Instant Answer
        try {
            val ddgUrl = "https://api.duckduckgo.com/"
            val ddg: DDGResponse = client.get(ddgUrl) {
                parameter("q", user)
                parameter("format", "json")
                parameter("no_redirect", "1")
                parameter("no_html", "1")
                accept(ContentType.Application.Json)
            }.body()
            val parts = mutableListOf<String>()
            if (!ddg.AbstractText.isNullOrBlank()) parts += ddg.AbstractText!!
            if (parts.isNotEmpty()) return@coroutineScope parts.joinToString(" ").take(1000)
            if (!ddg.Heading.isNullOrBlank()) parts += ddg.Heading!!
            if (parts.isNotEmpty()) return@coroutineScope parts.joinToString(" ").take(1000)
            if (ddg.RelatedTopics != null && ddg.RelatedTopics.isNotEmpty()) {
                val first = ddg.RelatedTopics.firstOrNull()
                val txt = first?.Text ?: first?.Topics?.firstOrNull()?.Text
                if (!txt.isNullOrBlank()) return@coroutineScope txt.take(1000)
            }
        } catch (_: Exception) {
            // continue to Wikipedia fallback
        }

        // Wikipedia REST summary API fallback
        try {
            val wikiUrl = "https://en.wikipedia.org/api/rest_v1/page/summary/" + user.replace(" ", "_")
            val wiki: WikiSummary = client.get(wikiUrl) {
                accept(ContentType.Application.Json)
            }.body()
            if (!wiki.extract.isNullOrBlank()) return@coroutineScope wiki.extract.take(1000)
        } catch (_: Exception) {
            // no-op
        }

        // small talk fallback
        return@coroutineScope "I couldn't find a direct answer. Try rephrasing or use 'search <term>' to open web results."
    }
}

@Serializable data class DDGResponse(val Heading: String? = null, val AbstractText: String? = null, val RelatedTopics: List<DDGTopic>? = null)
@Serializable data class DDGTopic(val Text: String? = null, val FirstURL: String? = null, val Topics: List<DDGTopic>? = null)

@Serializable data class WikiSummary(val title: String? = null, val extract: String? = null)
