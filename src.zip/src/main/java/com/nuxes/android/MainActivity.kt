package com.nuxes.android

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.Locale

// Note: This is a simplified, temporary implementation for demonstration.
// In a real app, this logic should be in a separate module.

// Data classes and enums for the chat functionality
data class ChatMessage(val role: String, val content: String, val attachmentUri: String? = null, val attachmentType: String? = null)

enum class Personality {
    FRIENDLY,
    HUMOROUS,
    PROFESSIONAL
}

class Assistant(private val personality: Personality) {
    fun handle(text: String, imageUri: Uri?, fileUri: Uri?): AssistantResponse {
        // This is a placeholder for your actual assistant logic.
        // It will generate a simple response based on the input text.
        val responseText = when (personality) {
            Personality.FRIENDLY -> "Hello! How can I help you today?"
            Personality.HUMOROUS -> "I'm a little busy talking to myself, but what's up?"
            Personality.PROFESSIONAL -> "Good day. Please state your query."
        }
        return AssistantResponse(responseText)
    }
}

class PublicLLMClient {
    // A placeholder class for your LLM client
}

data class AssistantResponse(
    val text: String,
    val openUrl: String? = null,
    val openAppHint: String? = null,
    val mediaQuery: String? = null,
    val target: String? = null,
    val dialNumber: String? = null,
    val smsTo: String? = null,
    val smsBody: String? = null
)

// Main Activity and UI
class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private val OVERLAY_REQUEST_CODE = 1234

    private lateinit var tts: TextToSpeech

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Handle language not supported
            }
        }
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, OVERLAY_REQUEST_CODE)
        }
    }

    private fun startOverlayServiceIfNeeded() {
        if (hasOverlayPermission()) {
            try {
                val svc = Intent(this, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(svc)
                } else {
                    startService(svc)
                }
            } catch (e: Exception) {}
        }
    }

    private fun stopOverlayServiceIfNeeded() {
        try {
            val svc = Intent(this, OverlayService::class.java)
            stopService(svc)
        } catch (e: Exception) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_EXTERNAL_STORAGE), 0)
        requestOverlayPermission()

        tts = TextToSpeech(this, this)

        setContent {
            MaterialTheme {
                AssistantScreen(tts)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        stopOverlayServiceIfNeeded()
    }

    override fun onStop() {
        super.onStop()
        startOverlayServiceIfNeeded()
        tts.stop()
        tts.shutdown()
    }
}

private fun openUrl(ctx: android.content.Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: ActivityNotFoundException) {}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantScreen(tts: TextToSpeech) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val assistant = remember { Assistant(Personality.FRIENDLY) }
    var input by remember { mutableStateOf(TextFieldValue("")) }
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val results = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val heard = results?.firstOrNull() ?: ""
            input = TextFieldValue(heard)
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            messages = messages + ChatMessage("user", "Image attached", attachmentUri = uri.toString(), attachmentType = "image")
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            messages = messages + ChatMessage("user", "File attached", attachmentUri = uri.toString(), attachmentType = "file")
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("AssistantKMM") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            LazyColumn(Modifier.weight(1f).padding(8.dp)) {
                items(messages) { m ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = if (m.role == "user") Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (m.role == "user") Color(0xFFE1F5FE) else Color(0xFFF1F8E9),
                            shape = MaterialTheme.shapes.medium,
                            tonalElevation = 1.dp
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(m.content)
                                Spacer(Modifier.height(6.dp))
                                m.attachmentUri?.let { uriStr ->
                                    if (m.attachmentType == "image") {
                                        AsyncImage(model = uriStr, contentDescription = "image", modifier = Modifier.size(120.dp))
                                    } else {
                                        Text("Attachment: " + uriStr, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type or press mic…") }
                )
                IconButton(onClick = {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    }
                    voiceLauncher.launch(intent)
                }) {
                    Text("🎤")
                }
                IconButton(onClick = { imagePicker.launch("image/*") }) { Text("🖼️") }
                IconButton(onClick = { filePicker.launch(arrayOf("*/*")) }) { Text("📎") }
                Button(onClick = {
                    val text = input.text.trim()
                    if (text.isNotEmpty()) {
                        messages = messages + ChatMessage("user", text)
                        input = TextFieldValue("")
                        scope.launch {
                            val result = assistant.handle(text, null, null)
                            messages = messages + ChatMessage("assistant", result.text)
                            result.openUrl?.let { url -> try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} }
                            result.openAppHint?.let { app -> when (app.lowercase()) { "youtube" -> openUrl(ctx, "https://www.youtube.com"); "spotify" -> openUrl(ctx, "https://open.spotify.com"); "maps" -> openUrl(ctx, "https://maps.google.com") else -> {} } }
                            result.mediaQuery?.let { q -> when (result.target) { "youtube" -> openUrl(ctx, "https://www.youtube.com/results?search_query=" + Uri.encode(q)); "spotify" -> openUrl(ctx, "https://open.spotify.com/search/" + Uri.encode(q)) } }
                            result.dialNumber?.let { num -> try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + num))) } catch (_: Exception) {} }
                            result.smsTo?.let { to -> val uri = Uri.parse("smsto:$to"); val intent = Intent(Intent.ACTION_SENDTO, uri).apply { putExtra("sms_body", result.smsBody ?: "") }; try { ctx.startActivity(intent) } catch (_: Exception) {} }
                            tts.speak(result.text, TextToSpeech.QUEUE_FLUSH, null, "reply")
                        }
                    }
                }) { Text("➤") }
            }
        }
    }
}
