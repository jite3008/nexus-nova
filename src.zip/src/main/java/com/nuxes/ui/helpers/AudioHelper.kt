package com.nuxes.ui.helpers

import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Environment
import java.io.File
import java.io.IOException

class AudioHelper {
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var lastFile: File? = null

    fun startRecording() {
        try {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "assistant_rec")
            if (!dir.exists()) dir.mkdirs()
            val out = File.createTempFile("rec_", ".m4a", dir)
            lastFile = out
            recorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(out.absolutePath)
                prepare()
                start()
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    fun stopRecording(): File? {
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) { e.printStackTrace() }
        recorder = null
        return lastFile
    }

    fun playLatest() {
        try {
            val f = lastFile ?: return
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(f.absolutePath)
                prepare()
                start()
            }
        } catch (e: Exception) { e.printStackTrace() }
    }
}