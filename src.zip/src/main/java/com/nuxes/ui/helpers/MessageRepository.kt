package com.nuxes.ui.helpers

import android.content.Context
import android.content.SharedPreferences

class MessageRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("assistant_prefs", Context.MODE_PRIVATE)

    fun saveMessage(id: String, text: String) {
        prefs.edit().putString("msg_$id", text).apply()
        // also maintain a simple index
        val index = prefs.getStringSet("index", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        index.add(id)
        prefs.edit().putStringSet("index", index).apply()
    }

    fun loadAll(): List<String> {
        val index = prefs.getStringSet("index", mutableSetOf()) ?: mutableSetOf()
        return index.mapNotNull { prefs.getString("msg_$it", null) }
    }

    fun saveApiKey(key: String) {
        prefs.edit().putString("api_key", key).apply()
        NetworkClient.apiKey = key
    }

    fun loadApiKey(): String? {
        val v = prefs.getString("api_key", null)
        NetworkClient.apiKey = v
        return v
    }
}