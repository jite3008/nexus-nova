package com.nuxes.ui.screens

import android.Manifest
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nuxes.ui.PolishedScaffold
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalContext
import android.speech.tts.TextToSpeech
import java.util.Locale
import com.nuxes.ui.helpers.NetworkClient
import com.nuxes.ui.helpers.MessageRepository

import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    modifier: Modifier = Modifier,
    onSendText: (String) -> Unit = {},
    onSendAudioFile: (File) -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<String>() }
    val ctx = LocalContext.current
    val repo = remember { MessageRepository(ctx) }
    val tts = remember { TextToSpeech(ctx) { } }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }


    PolishedScaffold(title = "Assistant Chat", onPrimaryAction = {}) { padding ->
        Column(modifier = Modifier
            .padding(padding)
            .fillMaxSize()) {

            LazyColumn(modifier = Modifier.weight(1f)) {
                items(messages) { m ->
                    Text(m, modifier = Modifier.padding(12.dp))
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextField(value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f), placeholder = { Text("Type a message") })
                IconButton(onClick = {
                    if (text.isNotBlank()) {
                        messages.add("You: $text")
                        onSendText(text)
                        text = ""
                    }
                }) {
                    Icon(Icons.Default.Send, contentDescription = "Send")
                }
            }
            // Audio controls (simple record/playback demo)
            AudioControls(onFileReady = {
                messages.add("You sent audio: ${it.name}")
                onSendAudioFile(it)
            })
        }
    }
}

@Composable
fun AudioControls(onFileReady: (File) -> Unit) {
    // Small demo UI that delegates recording/playback to a helper
    val recorder = remember { com.nuxes.ui.helpers.AudioHelper() }
    var recording by remember { mutableStateOf(false) }
    Column(Modifier.padding(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                recording = true
                recorder.startRecording()
            }) { Text("Record") }
            Button(onClick = {
                recording = false
                val f = recorder.stopRecording()
                if (f != null) onFileReady(f)
            }) { Text("Stop") }
            Button(onClick = { recorder.playLatest() }) { Text("Play") }
        }
        Text("Recording: ${if (recording) "ON" else "OFF"}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp))
    }
}