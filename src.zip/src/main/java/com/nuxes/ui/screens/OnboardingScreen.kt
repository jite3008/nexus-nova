package com.nuxes.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material3.MaterialTheme

@Composable
fun OnboardingScreen(onFinish: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Welcome to Assistant", style = MaterialTheme.typography.headlineSmall)
        Text("This app includes text & audio chat, TTS, and settings to store a public API key.", modifier = Modifier.padding(top=12.dp))
        Button(onClick = onFinish, modifier = Modifier.padding(top = 20.dp)) {
            Text("Get started") 
        }
    }
}